#
# TABLE STRUCTURE FOR: emails
#

DROP TABLE IF EXISTS emails;

CREATE TABLE `emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) CHARACTER SET utf8 NOT NULL,
  `subject` text CHARACTER SET utf8,
  `message` text CHARACTER SET utf8,
  `attachment` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `format_info` text CHARACTER SET utf8,
  `user_id` int(11) NOT NULL DEFAULT '1',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO emails (`id`, `type`, `subject`, `message`, `attachment`, `format_info`, `user_id`, `timestamp`) VALUES (1, 'forgot_password', 'Forgot Password', 'Hello #user_name <div><br></div><div>You have request for the reset the Password.<br></div><div>Please click the below link to reset password.<br>\r\n#reset_link</div><div><br></div><div>Thanks,</div><div>A.P.M.C Support Team</div>\r\n<div><hr>Please Click Here to <a href=\"http://#\" target=\"_blank\">unsubscribe</a></div>', 'd47359972cca7845d73580a6632825f0.jpeg', '#user_name\r\n#reset_link', 1, '2014-11-06 11:48:21');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS roles;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(65) NOT NULL,
  `permission` longtext,
  `created_id` int(11) NOT NULL,
  `create_date_time` datetime NOT NULL,
  `update_id` int(11) NOT NULL,
  `update_date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO roles (`id`, `name`, `permission`, `created_id`, `create_date_time`, `update_id`, `update_date_time`) VALUES (1, 'Super Admin', NULL, 1, '2015-03-24 16:06:20', 1, '2015-03-24 00:00:00');
INSERT INTO roles (`id`, `name`, `permission`, `created_id`, `create_date_time`, `update_id`, `update_date_time`) VALUES (2, 'Admin', 'a:1:{s:6:\"emails\";a:2:{i:0;s:9:\"viewEmail\";i:1;s:9:\"editEmail\";}}', 1, '2015-03-24 16:07:12', 1, '2015-03-24 00:00:00');


#
# TABLE STRUCTURE FOR: systemsettings
#

DROP TABLE IF EXISTS systemsettings;

CREATE TABLE `systemsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('general','mail','paypal','facebook','media') NOT NULL DEFAULT 'general',
  `sequence` int(3) NOT NULL,
  `sys_key` varchar(255) NOT NULL,
  `sys_value` text,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (1, 'general', 1, 'app_name', 'APMC', 1, '2014-08-07 09:00:31');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (2, 'general', 2, 'data_table_length', '25,50,75,100', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (3, 'mail', 1, 'protocol', 'smtp', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (4, 'mail', 2, 'smtp_host', 'ssl://smtp.gmail.com', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (5, 'mail', 4, 'smtp_user', 'ranasoyab@gmail.com', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (6, 'mail', 5, 'smtp_pass', NULL, 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (7, 'mail', 3, 'smtp_port', '465', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (8, 'general', 3, 'notification_timer', '5000', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (9, 'general', 4, 'copyright_left', 'All rights are reserved by APMC', 1, '2014-08-07 09:01:10');
INSERT INTO systemsettings (`id`, `type`, `sequence`, `sys_key`, `sys_value`, `user_id`, `timestamp`) VALUES (10, 'general', 5, 'copyright_right', 'Developed by RIS and Powered by DWSS', 1, '2014-08-07 09:01:10');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(65) NOT NULL,
  `password` varchar(65) NOT NULL,
  `fullname` varchar(65) NOT NULL,
  `profile_pic` varchar(65) DEFAULT 'no-avtar.png',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO users (`id`, `role_id`, `username`, `email`, `password`, `fullname`, `profile_pic`, `timestamp`) VALUES (1, 1, 'rana', 'ranasoyab@yopmail.com', '202cb962ac59075b964b07152d234b70', 'Soyab Rana', 'no-avtar.png', '2014-11-06 10:55:33');
INSERT INTO users (`id`, `role_id`, `username`, `email`, `password`, `fullname`, `profile_pic`, `timestamp`) VALUES (2, 2, 'temp', 'ranasoyab@yopmail.com', '202cb962ac59075b964b07152d234b70', 'Soyab Rana', 'no-avtar.png', '2014-11-06 10:55:33');


